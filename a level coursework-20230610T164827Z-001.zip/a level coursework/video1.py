#video test

##from tkinter import *
##from tkvideo import tkvideo
##
##vid_window = Tk()
##vid_window.title("Video")
##
##vid_window.geometry("640x512")
##video_label = Label(vid_window)
##video_label.pack()
##player = tkvideo(r"C:\Users\vickylam\Documents\a level coursework\1video.mp4", video_label, loop = 1, size = (1280,1024))
##player.play()
##
##vid_window.mainloop()
from os import startfile

startfile(r"C:\Users\vickylam\Documents\a level coursework\1video.mp4")
