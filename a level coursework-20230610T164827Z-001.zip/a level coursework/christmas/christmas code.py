#christmas card
from tkinter import *
from random import randint

root = Tk()
root.title("Merry Christmas")
root.geometry("1000x1000")
root.iconbitmap("christmas tree.ico")
colour="cornflower blue"
root.configure(bg=colour)

def play_music():
    Label(canvas, text="jingle bells", bg="lavender", fg="black",font="24").place(relx=0.5,rely=0.9, anchor="center")

#snow
def snow():
    xs =[]
    ys=[]
    size=[]
    for i in range(100):
        xs.append(randint(0, 1000))
        ys.append(randint(0, 1000))
        size.append(randint(1, 10))
    def snowfall():
        canvas.delete("all")
        #snowman
        canvas.create_oval(325, 450, 675, 775, fill="white", outline="white")
        canvas.create_oval(375, 320, 625, 570, fill="white", outline="white")
        canvas.create_oval(425, 200, 575,350, fill="white", outline="white")
        #smile
        coord = 475, 260, 525, 310
        arc = canvas.create_arc(coord, start=0, extent=-180, fill="pale violet red")
        canvas.create_oval(455, 230, 465,240, fill="black", outline="black")
        canvas.create_oval(535, 230, 545,240, fill="black", outline="black")
        #buttons
        canvas.create_oval(495, 380, 505,390, fill="black", outline="black")
        canvas.create_oval(495, 440, 505,450, fill="black", outline="black")
        canvas.create_oval(495, 520, 505,530, fill="black", outline="black")
        canvas.create_oval(495, 600, 505,610, fill="black", outline="black")
        canvas.create_oval(495, 680, 505,690, fill="black", outline="black")
        #arms
        canvas.create_line(250, 350, 380, 425, fill="brown")
        canvas.create_line(750, 350, 620, 425, fill="brown")
        #carrot
        canvas.create_polygon(490, 240, 510, 240,500, 270, fill="orange")
        for i in range(100):
            x = xs[i]
            y = ys[i]
            s = size[i]
            totalx=x+s
            totaly=y+s
            canvas.create_oval(x, y, totalx, totaly, fill="white", outline="white")
            ys[i] = ys[i] + (s / 10) 
            xs[i] = xs[i] - 5
            if y > 1000:
                ys[i] = 0
            if x < 0:
                xs[i] = 1000
            elif x > 1000:
                xs[i] = 0
        canvas.after(3, snowfall)
    snowfall()

class Window:
    def __init__(self, root):
        global canvas, canvas1
        canvas = Canvas(root, height=1000, width=1000, bg=colour)
        canvas.place(x=0, y=0)
        message = Button(canvas, text="Merry Christmas Rubes <3",command=snow)
        message.place(relx=0.5,rely=0.8, anchor="center")
        message = Button(canvas, text="And a Happy New Year!", command=play_music)
        message.place(relx=0.5,rely=0.85, anchor="center")

window=Window(root)

